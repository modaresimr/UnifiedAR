from general.utils import MyTask

class Combiner(MyTask):
    def combine(self,segment_data,act_data):
        pass;