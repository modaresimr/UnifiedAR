from general.utils import MyTask
import numpy as np
from general.sparray import sparray
def featureExtraction(feat,datasetdscr,s_event_list,windows,istrain):
    method=feat
    
    if(istrain):
        method.precompute(datasetdscr,windows)
    shape=method.getShape()

    if(len(shape)==1):
        result=np.zeros((len(windows),shape[0]))
    else:
        result= sparray((len(windows),shape[0],shape[1]),dtype=np.float)
        #result=np.zeros((len(windows),fw.shape[0],fw.shape[1]))
    
    for i in range(0,len(windows)):
        w=windows[i]
        #result[i]=method.featureExtract2(s_event_list,w)
        fw=method.featureExtract2(s_event_list,w)
        for j in fw.shape[0]:
            if(len(shape)==1):
              result[i,j]  =fw[i]
            else:
                for k in fw.shape[1]:
                    result[i,j,k]=fw[j,k]


    #result  =   np.array(result)
    
    return result

class FeatureExtraction(MyTask):
    def getShape(self):
        self.shape
    def precompute(self,datasetdscr,windows):
        self.datasetdscr=datasetdscr
        pass
    def featureExtract(self,window):
        pass
