from general.utils import MyTask


class Preprocessing(MyTask):

    def process(self, datasetdscr ,dataset):
        pass