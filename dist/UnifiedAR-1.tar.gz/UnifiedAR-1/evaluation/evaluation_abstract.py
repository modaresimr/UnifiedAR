from general.utils import MyTask


class Evaluation(MyTask):

    def precompute(self):
        pass

    def evaluate(self,dataset,func):
        pass