
# #get_ipython().run_line_magic('load_ext', 'autoreload')
# #get_ipython().run_line_magic('autoreload', '2')
# from IPython import get_ipython
# from general.libinstall import *
# from tqdm import tqdm
# from sklearn import svm
# import sklearn.metrics 
# from memory_profiler import profile
# import numpy as np
# import pandas as pd
# import os
# import wget
# #get_ipython().run_line_magic('matplotlib', 'inline')
# import matplotlib.pyplot as plt
# import seaborn as sns;

# import tensorflow as tf
# import json
# from intervaltree import IntervalTree




# from textwrap import wrap
# import re
# import itertools
# import tfplot
# import matplotlib
# from sklearn.metrics import confusion_matrix

# import skopt


# from sklearn.model_selection import KFold
# from scipy import optimize
# import multiprocessing as mp
# from joblib import parallel_backend,Parallel, delayed

# print('Libraries loaded successfully.');